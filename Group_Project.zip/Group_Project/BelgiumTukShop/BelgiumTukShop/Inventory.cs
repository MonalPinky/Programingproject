﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BelgiumTukShop
{
    public partial class Inventory : Form
    {
       public DataTable table = new DataTable("table");
      
        public Inventory()
        {
            InitializeComponent();
            DisplayGrid();
        }
        //To display all items in the text file to the datagrid
       public  void DisplayGrid()
        {
            Items Obj1 = new Items();
            List<Items> items = new List<Items>();

            items.Clear();
            dataGridView1.Rows.Clear();

            foreach (var listitem in Obj1.Path1)
            {
                string[] temp = listitem.Split(',');
                try
                {
                    items.Add(new Items { Name = temp[0], Quantitiy = int.Parse(temp[1]), Category = temp[2], Price = double.Parse(temp[3]) });

                }
                catch
                {
                    MessageBox.Show("The sorcefile was messed with please go to debug/list.txt and delte all the items ");
                }
            }
            foreach (var item in items)
            {
                dataGridView1.Rows.Add(item.Name, item.Quantitiy, item.Category, item.Price);
            }



        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public delegate void eventcheck();
        public event eventcheck check;
        //add item to inventory
        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                if (txtName.Text != null && txtQuantity.Text != null && listcategroy.Text != null && txtPrice.Text != null)
                {
                    check = null;
                    Items Obj1 = new Items();
                    List<Items> items = new List<Items>();
                    string name = txtName.Text;
                    string quantity = txtQuantity.Text;
                    string exstra = listcategroy.Text;
                    string price = txtPrice.Text;


                    if (int.Parse(quantity) > 0 && double.Parse(price) > 0)
                    {
                        foreach (var listitem in Obj1.Path1)
                        {
                            string[] temp = listitem.Split(',');
                            if (temp[0] == name)
                            {
                                throw new Exception("Name Already taken change name");
                            }

                        }
                        if (check == null)
                        {
                            Obj1.SaveToTxT(name, quantity, exstra, price, " ");
                            dataGridView1.Rows.Add(name, quantity, exstra, price);
                            DisplayGrid();
                        }
                        else
                        {
                            throw new Exception("Price or quantity in wrong format price:decimal quantity intreger");
                        }

                    }
                    else
                    {
                        throw new Exception("All fileds have to be filled out ");
                    }
                }
            }
            catch (Exception ex)
            {
                if (ex.GetType().ToString() == "System.FormatException")
                {
                    System.Windows.Forms.MessageBox.Show("Price and quantity either  not filed in or wrong format interger for quantity and double for price");
                }
                else
                {
                    check += Inventory_check;
                    // "Wrong format quantity = interger price =decimal"
                    System.Windows.Forms.MessageBox.Show(ex.ToString());

                }

            }

        }

        private void Inventory_check()
        {
            throw new NotImplementedException();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

           
        }
        //clear all filds
        private void button3_Click(object sender, EventArgs e)
        {
            txtName.Text = string.Empty;
            txtPrice.Text = string.Empty;
            txtQuantity.Text = string.Empty;
            
            
        }
        //removes selected item
        private void button4_Click(object sender, EventArgs e)
        {
            string cellValue;
            Items obj = new Items();
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int selectedrowindex = dataGridView1.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = dataGridView1.Rows[selectedrowindex];
                cellValue = Convert.ToString(selectedRow.Cells[0].Value);
                obj.removeItem(cellValue);
                DisplayGrid();
            }
            
        }
        // updates items that are selected
        private void button2_Click(object sender, EventArgs e)
        {
            string cellValue;
            Items obj = new Items();
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int selectedrowindex = dataGridView1.SelectedCells[0].RowIndex;
                DataGridViewRow selectedRow = dataGridView1.Rows[selectedrowindex];
                cellValue = Convert.ToString(selectedRow.Cells[0].Value);
                string path = Environment.CurrentDirectory + "//Item.txt";
                List<string> UpdatedList = new List<string>();
                foreach (var item in obj.Path1)
                {
                    string[] temp = item.Split(',');
                    if (cellValue == temp[0])
                    {
                        UpdatedList.Add(txtName.Text + "," + txtQuantity.Text + "," + listcategroy.Text + "," + txtPrice.Text);
                    }
                    else
                    {
                        UpdatedList.Add(temp[0] + "," + temp[1] + "," + temp[2] + "," + temp[3]);

                    }
                }
                File.Delete(path);
                File.WriteAllLines(path, UpdatedList);

                DisplayGrid();
            }
        }
    }
}

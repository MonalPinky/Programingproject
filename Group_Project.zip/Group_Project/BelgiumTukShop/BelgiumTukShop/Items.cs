﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BelgiumTukShop
{
    internal class Items :IProducts
    {
        string name;
        string category;
        int quantitiy;
        double price;
       List<string> Path = File.ReadAllLines(Environment.CurrentDirectory + "//Item.txt").ToList();

        public List<string> Path1 { get => Path; set => Path = value; }
        public string Name { get => name; set => name = value; }
        public int Quantitiy { get => quantitiy; set => quantitiy = value; }
        public double Price { get => price; set => price = value; }
        public string Category { get => category; set => category = value; }

        public void SaveToTxT(string name, string quantity, string exstra, string Price, string ordernumber)
        {
            using (StreamWriter ItemAdd = File.AppendText(Environment.CurrentDirectory + "//Item.txt"))
            {
                ItemAdd.WriteLine(name + "," + quantity + "," + exstra + "," + Price);
            }


        }
        public void Update(string updateName ,string quantity,string exstra ,string Price ,string ordernumber)
        {
            string path = Environment.CurrentDirectory + "//Item.txt";
            List<string> UpdatedList = new List<string>();
            foreach (var item in Path1)
            {
                string[] temp = item.Split(',');
                if (updateName == temp[0])
                {
                    UpdatedList.Add(updateName + "," + quantity + "," + exstra + "," + Price);
                }
                else
                {
                    UpdatedList.Add(temp[0] + "," + temp[1] + "," + temp[2] + "," + temp[3]);
                   
                }
            }
            File.Delete(path);
            File.WriteAllLines(path, UpdatedList);
        }
        public void removeItem(string RemoveName)
        {
            string path = Environment.CurrentDirectory + "//Item.txt";
            List<string> UpdatedList = new List<string>();
            foreach (var item in Path1)
            {
                string[] temp = item.Split(',');
                if (RemoveName != temp[0])
                {
                    UpdatedList.Add(temp[0] + "," + temp[1] + "," + temp[2] + "," + temp[3]);
                }
            }
            File.Delete(path);
           File.WriteAllLines(path, UpdatedList);    
        }
        public void TxtToList(List<Items> listname)
        {
            
            foreach (var listitem in Path1)
            {
                string[] temp = listitem.Split(',');

                listname.Add(new Items { Name = temp[0], Quantitiy = int.Parse(temp[1]), Category = temp[2], Price = double.Parse(temp[3]) });
            }
           

        }
    }
}

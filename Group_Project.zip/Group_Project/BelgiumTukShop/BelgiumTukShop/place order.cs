﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BelgiumTukShop
{
    public partial class place_order : Form
    {
        //This is to keep the order number new 
       public static List<string> numbers = File.ReadAllLines(Environment.CurrentDirectory + "//OrderNumber.txt").ToList();
        //value = first ietm in the list the list only has one item 
        int orderNumber = int.Parse(numbers[0]);
        public static List<string> Temp = new List<string>();

        public delegate void Footer();
        public static event Footer eventFooter;

        public static void eventInvoke()
        {
            if (eventFooter != null)
            {
                eventFooter();
            }
        }
        public place_order()
        {
            InitializeComponent();
            loadListBox();
            
        }
        public void TotalCheck()
        {

            DataGridViewRow row = (DataGridViewRow)dataGridView1.Rows[0].Clone();


            Orders obj = new Orders();
            //TO make a row at the bottom of the datagrid so we can see total and order number


            row.Cells[0].Value = "Order Total:";
            row.Cells[1].Value = obj.total(orderNumber);
            row.Cells[2].Value = "Order Number:";
            row.Cells[3].Value = orderNumber;
            row.DefaultCellStyle.BackColor = Color.DimGray;

            dataGridView1.Rows.Add(row);


        }
        public void loadListBox()
        {
            //takes items from items and adds all the items to the list 
            Items ob = new Items();
            foreach (var item in ob.Path1)
            {
                string[] temp = item.Split(',');
                liName.Items.Add(temp[0]);
            }
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        //Add item to list 
        private void button1_Click(object sender, EventArgs e)
        {
            int price =0;
            Orders orderobj = new Orders();
            Items itemobj = new Items();
            foreach (var item in itemobj.Path1)
            {
                string[] temp = item.Split(',');
                if (liName.Text == temp[0])
                {
                    price = int.Parse(temp[3]) * int.Parse(txtQuantity.Text);
                    orderobj.SaveToTxT(liName.Text, txtQuantity.Text, txtExstra.Text, price.ToString(), orderNumber.ToString());
                    dataGridView1.Rows.Add(liName.Text, txtQuantity.Text, price.ToString(),txtExstra.Text);
               
                }
            }

            
            
            
        }
        //Place orders
        private void button2_Click(object sender, EventArgs e)
        {
            Orders obj = new Orders();

            obj.orderTOTxt(orderNumber);
            string path = Environment.CurrentDirectory + "//OrderNumber.txt";

            //to increase the order number
            orderNumber++;

            Temp.Clear();
            Temp.Add(orderNumber.ToString());

            //Deltes the privous number and adds the new temp list with one item there
            File.Delete(path);
            File.WriteAllLines(path, Temp);

            //Clears the datagrid so the new orders items can be there
            dataGridView1.Rows.Clear();
            TotalCheck();
        }
        //shows order total
        private void button1_Click_1(object sender, EventArgs e)
        {
            TotalCheck();
        }
    }
}

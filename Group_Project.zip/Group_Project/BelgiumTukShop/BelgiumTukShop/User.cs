﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BelgiumTukShop
{
    public delegate string EventDelegare();
    internal class User
    {
      
        string password, Name;

        public string Password { get => password; set => password = value; }
        public string Name1 { get => Name; set => Name = value; }
        public void setname(string newname)
        {
            Name = newname;
        }
        public string nameToAccount()
        {
            return Name;
        }
       
    }
}

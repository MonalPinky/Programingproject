﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BelgiumTukShop
{
    public partial class Account : Form
    {
        
        public Account()
        {
            InitializeComponent();
            accountname();
            
        }
        
        public string accountname()
        {
            Login f1 = new Login();

            string text = f1.UserName;
            return text;
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void Account_Load(object sender, EventArgs e)
        {
         
        }
        //saves details
        private void button1_Click(object sender, EventArgs e)
        {
            int count = 0;
            List<string> AllUsers = System.IO.File.ReadAllLines(Environment.CurrentDirectory + "//User.txt").ToList();
            string path = Environment.CurrentDirectory + "//User.txt";
            List<string> updatedusers = new List<string>();

            try
            {
                foreach (var item in AllUsers)
                {
                    string[] temp = item.Split(',');
                    if (temp[0] == txtUserName.Text && temp[1] == txtCurrentPass.Text)
                    {
                        updatedusers.Add(txnewName.Text + "," + TxtNewPass.Text);
                        count++;

                    }

                    else
                    {
                        updatedusers.Add(temp[0] + "," + temp[1]);

                    }
                }
                    

                
                if (count !=1)
                {
                    throw new Exception("password or username incorrect");
                }
                File.Delete(path);
                File.WriteAllLines(path, updatedusers);
                MessageBox.Show("Successfully added");
                txtCurrentPass.Clear();
                txtUserName.Clear();
                TxtNewPass.Clear();
                txnewName.Clear();
                updatedusers.Clear();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void Account_eventCheck()
        {
            throw new NotImplementedException();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}

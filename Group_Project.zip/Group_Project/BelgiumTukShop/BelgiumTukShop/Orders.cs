﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BelgiumTukShop
{
    internal class Orders:IProducts
    {
        List<string> Order = File.ReadAllLines(Environment.CurrentDirectory + "//Orders.txt").ToList();
        List<string> OrderItems = File.ReadAllLines(Environment.CurrentDirectory + "//OrdersItems.txt").ToList();

        public List<string> Order1 { get => Order; set => Order = value; }
        public List<string> OrderItems1 { get => OrderItems; set => OrderItems = value; }

        //To save the paramenters to a txt file 
        public void SaveToTxT(string name, string quantity, string exstra, string Price,string ordernumber)
        {
            using (StreamWriter ItemAdd = File.AppendText(Environment.CurrentDirectory + "//OrdersItems.txt"))
            {
                ItemAdd.WriteLine(name+","+quantity+ ","+exstra+ ","+Price + "," + ordernumber);

            }
          
        }
        public int total (int ordernumber)
        {
            int total = 0;
            foreach (var item in OrderItems)
            {
                string[] temp = item.Split(',');
                if (ordernumber == int.Parse(temp[4]))
                {
                    total += int.Parse(temp[3]);
                }
            }
            return total;
        }
        //To save orders to a txt file
        public void orderTOTxt(int ordernumber)
        {
            using (StreamWriter ItemAdd = File.AppendText(Environment.CurrentDirectory + "//Orders.txt"))
            {
                int total = 0;
                foreach (var item in OrderItems)
                {
                   
                    string[] temp = item.Split(',');
                    if (ordernumber == int.Parse(temp[4]))
                    {
                        total += int.Parse(temp[3]);
                        
                    }
                }
                ItemAdd.WriteLine(ordernumber + "," + total+","+"false");

            }
        }
    }
}

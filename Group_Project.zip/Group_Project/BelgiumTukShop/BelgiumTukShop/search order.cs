﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BelgiumTukShop
{
    public partial class search_order : Form
    {
        public search_order()
        {
            InitializeComponent();
        }
        List<string> AllOrderItem = File.ReadAllLines(Environment.CurrentDirectory+ "//OrdersItems.txt").ToList();
        List<string> Order = File.ReadAllLines(Environment.CurrentDirectory + "//Orders.txt").ToList();
        //buttons and grid populate
        public void populate()
        {
            dataGridView1.Rows.Clear();
            Orders obj = new Orders();
            for (int i = 0; i < AllOrderItem.Count; i++)
            {
                string[] tem = AllOrderItem[i].Split(',');
                if (txtOrderNumber.Text == tem[4])
                {
                    for (int j = 0; j < Order.Count; j++)
                    {
                        string[] ordertemp = Order[j].Split(',');
                        if (ordertemp[0] == tem[4])
                        {
                            if (ordertemp[2] == "false")
                            {
                                dataGridView1.Rows.Add(tem[0], tem[1], tem[3], "incomplete");
                            }
                            else
                            {
                                dataGridView1.Rows.Add(tem[0], tem[1], tem[3], "done");
                            }
                          ;
                        }
                    }

                }
                
            }//TO make a row at the bottom of the datagrid so we can see total and order number
            DataGridViewRow row = (DataGridViewRow)dataGridView1.Rows[0].Clone();
            Orders obj1 = new Orders();
            row.Cells[0].Value = "Order Total:";
            row.Cells[1].Value = obj.total(int.Parse(txtOrderNumber.Text));
            row.Cells[2].Value = "Order Number:";
            row.Cells[3].Value = int.Parse(txtOrderNumber.Text);
            row.DefaultCellStyle.BackColor = Color.DimGray;

            dataGridView1.Rows.Add(row);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            
          
            if (dataGridView1.Visible ==true)
            {
                dataGridView1.Visible = false;
                button2.Visible = false;
                btnOrderCOmplete.Visible = false;
                btnsearch2.Visible = false;
            }
            else
            {
                dataGridView1.Visible=true;
                button2.Visible = true;
                btnOrderCOmplete.Visible = true;
                btnsearch2.Visible=true;
            }
            try
            {
                populate();
            }
            catch (Exception )
            {

                MessageBox.Show("please don't leave the order search empty");
            }
          
        }
        //To display the grid and buttons
        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Visible == true)
            {
                dataGridView1.Visible = false;
                button2.Visible = false;
                btnOrderCOmplete.Visible = false;
            }
            else
            {
                dataGridView1.Visible = true;
                button2.Visible = true;
                btnOrderCOmplete.Visible = true;
            }
        }

        
        //Changes an order to complete and saves it on the order text file
        private void btnOrderCOmplete_Click(object sender, EventArgs e)
        {
            this.Focus();
            List<string> templist = new List<string>();
            dataGridView1.Rows.Clear();
            Orders obj = new Orders();
            string path = Environment.CurrentDirectory + "//Orders.txt";
         
            for (int j = 0; j < Order.Count; j++)
            {
                string[] temporder = Order[j].Split(',');
                  if (txtOrderNumber.Text == temporder[0])
                  {
                      templist.Add(temporder[0] + "," + temporder[1] + "," + "true");
                     
                  }
                  else
                  {
                      templist.Add(temporder[0] + "," + temporder[1] + "," + temporder[2]);
                    
                }
            }
           Order = File.ReadAllLines(Environment.CurrentDirectory + "//Orders.txt").ToList();
            populate();
            File.Delete(path);
            File.WriteAllLines(path, templist);

            
        }
        //searches for items
        private void btnsearch2_Click(object sender, EventArgs e)
        {
            populate();
        }

        private void txtOrderNumber_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BelgiumTukShop
{
    public partial class All_orders : Form
    {
        public static List<string> numbers = File.ReadAllLines(Environment.CurrentDirectory + "//OrderNumber.txt").ToList();
        //value = first ietm in the list the list only has one item 
        int orderNumber = int.Parse(numbers[0]);
        public All_orders()
        {
            InitializeComponent();
        }
        public void ordertotalnumber(int i)
        {
            DataGridViewRow row = (DataGridViewRow)dataGridView1.Rows[0].Clone();
            Orders obj = new Orders();
            row.Cells[0].Value = "Order Total:";
            row.Cells[1].Value = obj.total(i);
            row.Cells[2].Value = "Order Number:";
            row.Cells[3].Value = i;
            row.DefaultCellStyle.BackColor = Color.DimGray;

            dataGridView1.Rows.Add(row);
        }
        List<string> AllOrderItmes = File.ReadAllLines(Environment.CurrentDirectory + "//OrdersItems.txt").ToList();
        List<string> OrderItmes = new List<string>();
       
        private void All_orders_Load(object sender, EventArgs e)
        {
            Orders obj = new Orders();
            bool flag = false;
           
            for (int i = 0; i < orderNumber; i++)
            {
                foreach (var item in AllOrderItmes)
                {
                    string[] temp = item.Split(',');
                    if (int.Parse(temp[4]) ==i)
                    {
                        dataGridView1.Rows.Add(temp[0], temp[1], temp[3]);
                    }
                    else
                    {
                        flag = true;
                    }
                }
                if (flag == true)
                {
                    ordertotalnumber(i);
                }

            }
        }     
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BelgiumTukShop
{
    internal interface IProducts
    {
        void SaveToTxT(string name,string quantity,string exstra,string Price ,string ordernumber);
    }
}

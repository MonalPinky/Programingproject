﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BelgiumTukShop
{
    public partial class Login : Form
    {
       
        
        public Login()
        {
            InitializeComponent();
           
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            this.panel1.BackColor = Color.FromArgb(120, 253, 218, 37);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        public string UserName;
        private void button1_Click(object sender, EventArgs e)
        {
            Account account = new Account();
            account.accountname();
            //Saves content of txt file to an array 
            string[] User = System.IO.File.ReadAllLines(Environment.CurrentDirectory + "//User.txt");
            string name = txtUser.Text;
           
            string pass = txtPass.Text;
            Form1 frm = new Form1();

            foreach (var item in User)
            {
                //changes each item in the User to an array in its own to check if it what was type 
                string[] temp = item.Split(',');
                if (name == temp[0] && pass == temp[1])
                {
                    
                    Thread.Sleep(400);
                    frm.Show();
                    this.Hide();
                }
            }
            if (frm.Visible == false)
            {
                System.Windows.Forms.MessageBox.Show(@"Username :admin  Password: admin all passwords in text file user debug/ user.txt");
                passincorrect.Visible = true;
            }
            
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.passincorrect.BackColor = Color.FromArgb(120, 255, 255, 0);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.label2.BackColor = Color.FromArgb(120, 255, 255, 0);
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.label3.BackColor = Color.FromArgb(120, 255, 255, 0);
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void showUser_Click(object sender, EventArgs e)
        {
            this.passincorrect.BackColor = Color.FromArgb(120, 255, 255, 0);
        }
    }
}

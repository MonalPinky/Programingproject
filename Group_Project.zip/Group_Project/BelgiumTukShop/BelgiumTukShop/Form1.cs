﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BelgiumTukShop
{
    public partial class Form1 : Form
    {
        public Form1()
        {

            InitializeComponent();
        }
        
      //closes the sidebar
        private void button2_Click(object sender, EventArgs e)
        {
            if (mainMenuPa.Visible == true)
            {
                mainMenuPa.Visible = false;
                OpenPanel.Visible = true;
            }
            else if (mainMenuPa.Visible == false)
            {
                mainMenuPa.Visible = true;
                OpenPanel.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (mainMenuPa.Visible == true)
            {
                Thread.Sleep(300);
                mainMenuPa.Visible = false;
                Thread.Sleep(300);
                OpenPanel.Visible = true;
            }
            else if (mainMenuPa.Visible == false)
            {
                Thread.Sleep(300);
                mainMenuPa.Visible = true;
                Thread.Sleep(300);
                OpenPanel.Visible = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
           
        }
        //opnes order submenu
        private void button4_Click(object sender, EventArgs e)
        {
            if (popup.Visible==false)
            {
                Thread.Sleep(300);
                popup.Visible = true;
            }
            else
            {
                Thread.Sleep(300);
                popup.Visible = false;
            }
        }
        //opnes inventory
        private void btnInventory_Click(object sender, EventArgs e)
        {
            this.MainForm.Controls.Clear();
            Inventory frm = new Inventory() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            this.MainForm.Controls.Add(frm);
            frm.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }
        //opens account change
        private void button5_Click(object sender, EventArgs e)
        {
            this.MainForm.Controls.Clear();
            Account frm = new Account() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            this.MainForm.Controls.Add(frm);
            frm.Show();
        }

        private void MainForm_Paint(object sender, PaintEventArgs e)
        {

        }
        //opens side bar submenu
        private void button10_Click_1(object sender, EventArgs e)
        {
            if (panel6.Visible == false)
            {
                panel6.Visible = true;
            }
            else
            {
                panel6.Visible = false;
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Login f = new Login();
            this.Hide();
            f.Show();
        }
        //logs out
        private void button16_Click(object sender, EventArgs e)
        {
            Login f = new Login();
            this.Hide();
            f.Show();
        }

        private void Header_Paint(object sender, PaintEventArgs e)
        {

        }
        //opens side bar
        private void OpenButton_Click(object sender, EventArgs e)
        {
            if (mainMenuPa.Visible == true)
            {
                Thread.Sleep(300);
                mainMenuPa.Visible = false;
                Thread.Sleep(300);
                OpenPanel.Visible = true;
            }
            else if (mainMenuPa.Visible == false)
            {
                Thread.Sleep(300);
                mainMenuPa.Visible = true;
                Thread.Sleep(300);
                OpenPanel.Visible = false;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
           

        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            this.MainForm.Controls.Clear();
            Inventory frm = new Inventory() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            this.MainForm.Controls.Add(frm);
            frm.Show();
        }
        //opens place order
        private void button6_Click(object sender, EventArgs e)
        {
            this.MainForm.Controls.Clear();
            place_order frm = new place_order() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            this.MainForm.Controls.Add(frm);
            frm.Show();
        }
        //place orders
        private void button12_Click(object sender, EventArgs e)
        {
            this.MainForm.Controls.Clear();
            place_order frm = new place_order() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            this.MainForm.Controls.Add(frm);
            frm.Show();
        }
        //opnes order search
        private void button7_Click(object sender, EventArgs e)
        {
            this.MainForm.Controls.Clear();
            search_order frm = new search_order() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            this.MainForm.Controls.Add(frm);
            frm.Show();
        }
        //opens order search
        private void button13_Click(object sender, EventArgs e)
        {
            this.MainForm.Controls.Clear();
            search_order frm = new search_order() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            this.MainForm.Controls.Add(frm);
            frm.Show();
        }
        //opens all orders
        private void button8_Click(object sender, EventArgs e)
        {
            this.MainForm.Controls.Clear();
            All_orders frm = new All_orders() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            this.MainForm.Controls.Add(frm);
            frm.Show();
        }
        //opnes all orders
        private void button14_Click(object sender, EventArgs e)
        {
            this.MainForm.Controls.Clear();
            All_orders frm = new All_orders() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            this.MainForm.Controls.Add(frm);
            frm.Show();
        }
        //Opens account add
        private void button11_Click_1(object sender, EventArgs e)
        {
            this.MainForm.Controls.Clear();
            Account frm = new Account() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true };
            this.MainForm.Controls.Add(frm);
            frm.Show();
        }
        //logs out
        private void button15_Click_1(object sender, EventArgs e)
        {
            Login f = new Login();
            this.Hide();
            f.Show();
        }
    }
}
